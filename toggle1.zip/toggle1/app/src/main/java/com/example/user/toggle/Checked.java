package com.example.user.toggle;

/**
 * Created by user on 24-01-2017.
 */
public class Checked {
}
