package com.example.user.toggle;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ToggleButton;
import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;
import android.widget.ToggleButton;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    TextView textView;


    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = (TextView) findViewById(R.id.result_text);
        textView.setVisibility(View.INVISIBLE);
    }
    public void changeState(View view)
    {
        boolean checked= ((ToggleButton)view).isChecked();


        if (checked)
        {

            textView.setText("Ramkumar");
            textView.setVisibility(View.VISIBLE);
        }
        else

        {
            textView.setText("");

        }



    }
}